// Javascript Controllers for Student Predictive Maintenance Dashboard

document.addEventListener('DOMContentLoaded', () => {
    // 1. Navigation SPA Routing
    setupNavigation();
    
    // 2. Telemetry Form Inputs Sync
    setupSliders();
    
    // 3. Module 3 Form Submission
    setupPredictionForm();
    
    // 4. Initial Load
    fetchPredictionHistory();
});

// Global instances of Chart.js objects to prevent overlap issues
let m1PieChart = null;
let m1BarChart = null;
let m2ImportanceChart = null;
let m3RadarChart = null;

/**
 * Handle switching between different pages/modules
 */
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const pageId = item.getAttribute('data-page');
            switchPage(pageId);
        });
    });
}

function switchPage(pageId) {
    // Update active nav button
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(btn => {
        if (btn.getAttribute('data-page') === pageId) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    // Update active section visibility
    const sections = document.querySelectorAll('.page-section');
    sections.forEach(section => {
        if (section.id === pageId) {
            section.classList.add('active');
        } else {
            section.classList.remove('active');
        }
    });

    // Lazy load page-specific stats & charts
    if (pageId === 'module1-page') {
        loadModule1Data();
    } else if (pageId === 'module2-page') {
        loadModule2Data();
    } else if (pageId === 'module3-page') {
        loadModule3Data();
    }
}

/**
 * Synchronize slider controls with their numerical values labels
 */
function setupSliders() {
    const sliders = [
        { id: 'input-temp', valId: 'val-temp', decimals: 1 },
        { id: 'input-speed', valId: 'val-speed', decimals: 0 },
        { id: 'input-torque', valId: 'val-torque', decimals: 1 },
        { id: 'input-wear', valId: 'val-wear', decimals: 0 },
        { id: 'input-vibration', valId: 'val-vibration', decimals: 1 },
        { id: 'input-pressure', valId: 'val-pressure', decimals: 0 }
    ];

    sliders.forEach(slider => {
        const inputEl = document.getElementById(slider.id);
        const valEl = document.getElementById(slider.valId);
        if (inputEl && valEl) {
            // Slider dragging updates manual input
            inputEl.addEventListener('input', (e) => {
                valEl.value = parseFloat(e.target.value).toFixed(slider.decimals);
                if (m3RadarChart) {
                    updateRadarChartLive();
                }
            });

            // Manual input changes update slider
            valEl.addEventListener('input', (e) => {
                let val = parseFloat(e.target.value);
                if (!isNaN(val)) {
                    // Clamp to min/max of slider
                    const min = parseFloat(inputEl.min);
                    const max = parseFloat(inputEl.max);
                    if (val < min) val = min;
                    if (val > max) val = max;
                    
                    inputEl.value = val;
                    if (m3RadarChart) {
                        updateRadarChartLive();
                    }
                }
            });

            // Sync on blur: if user typed something weird, re-sync to the actual slider value
            valEl.addEventListener('blur', () => {
                valEl.value = parseFloat(inputEl.value).toFixed(slider.decimals);
            });
        }
    });
}

/**
 * MODULE 1: Fetch Preprocessing metrics & draw charts
 */
function loadModule1Data() {
    fetch('/api/sensor-data')
        .then(res => res.json())
        .then(data => {
            // Update stats cards
            document.getElementById('m1-total-records').innerText = data.total_records_clean;
            document.getElementById('m1-missing-values').innerText = data.missing_values.Total;
            document.getElementById('m1-duplicate-records').innerText = data.duplicates;
            document.getElementById('m1-total-features').innerText = data.features.length;

            // Chart 1: Condition Distribution (Pie Chart)
            const ctxPie = document.getElementById('m1-pie-chart').getContext('2d');
            if (m1PieChart) m1PieChart.destroy();
            m1PieChart = new Chart(ctxPie, {
                type: 'pie',
                data: {
                    labels: ['Healthy Equipment', 'Fault / Failure Predicted'],
                    datasets: [{
                        data: [data.healthy_count, data.failures_count],
                        backgroundColor: ['rgba(16, 185, 129, 0.65)', 'rgba(239, 68, 68, 0.65)'],
                        borderColor: ['#10b981', '#ef4444'],
                        borderWidth: 1.5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#f1f5f9' } }
                    }
                }
            });

            // Chart 2: Means comparison (Bar Chart)
            const ctxBar = document.getElementById('m1-bar-chart').getContext('2d');
            if (m1BarChart) m1BarChart.destroy();
            m1BarChart = new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: ['Temperature (°C)', 'Vibration (mm/s)'],
                    datasets: [
                        {
                            label: 'Healthy State',
                            data: [data.temp_healthy_mean, data.vibe_healthy_mean],
                            backgroundColor: 'rgba(59, 130, 246, 0.6)',
                            borderColor: '#3b82f6',
                            borderWidth: 1
                        },
                        {
                            label: 'Failure State',
                            data: [data.temp_fail_mean, data.vibe_fail_mean],
                            backgroundColor: 'rgba(249, 115, 22, 0.6)',
                            borderColor: '#f97316',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#f1f5f9' } }
                    },
                    scales: {
                        x: { ticks: { color: '#94a3b8' } },
                        y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255, 255, 255, 0.05)' } }
                    }
                }
            });
        })
        .catch(err => console.error("Error loading Module 1 data:", err));
}

/**
 * MODULE 2: Fetch Model comparison & Explainable AI
 */
function loadModule2Data() {
    fetch('/api/model-info')
        .then(res => res.json())
        .then(data => {
            // Update Best Model Header banner
            document.getElementById('best-model-name').innerText = data.best_model_name;
            document.getElementById('saved-model-status').innerText = `Model Status: ${data.saved_model_status}`;

            // Populate Algorithm comparison table
            const tableBody = document.getElementById('model-comparison-table-body');
            tableBody.innerHTML = '';
            
            Object.keys(data.model_comparison).forEach(modelName => {
                const metrics = data.model_comparison[modelName];
                const isBest = modelName === data.best_model_name;
                const row = document.createElement('tr');
                if (isBest) row.classList.add('highlight');
                
                row.innerHTML = `
                    <td>${modelName} ${isBest ? '<i class="fa-solid fa-star" style="color:#00f2fe; margin-left:5px;"></i>' : ''}</td>
                    <td>${(metrics.Accuracy * 100).toFixed(1)}%</td>
                    <td>${(metrics.Precision * 100).toFixed(1)}%</td>
                    <td>${(metrics.Recall * 100).toFixed(1)}%</td>
                    <td>${(metrics['F1-Score'] * 100).toFixed(1)}%</td>
                    <td>${(metrics['ROC-AUC'] * 100).toFixed(1)}%</td>
                `;
                tableBody.appendChild(row);
            });

            // Update Confusion Matrix Grid values
            document.getElementById('cm-tn').innerText = data.confusion_matrix.TN;
            document.getElementById('cm-fp').innerText = data.confusion_matrix.FP;
            document.getElementById('cm-fn').innerText = data.confusion_matrix.FN;
            document.getElementById('cm-tp').innerText = data.confusion_matrix.TP;

            // Draw SHAP/Feature Importance chart
            const ctxImp = document.getElementById('m2-importance-chart').getContext('2d');
            if (m2ImportanceChart) m2ImportanceChart.destroy();
            
            const labels = Object.keys(data.feature_importances);
            const values = Object.values(data.feature_importances);
            
            m2ImportanceChart = new Chart(ctxImp, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Feature Influence Score (%)',
                        data: values,
                        backgroundColor: 'rgba(168, 85, 247, 0.65)',
                        borderColor: '#a855f7',
                        borderWidth: 1.5
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        x: { 
                            ticks: { color: '#94a3b8' }, 
                            grid: { color: 'rgba(255, 255, 255, 0.05)' },
                            title: { display: true, text: 'Percentage Influence (%)', color: '#94a3b8' }
                        },
                        y: { ticks: { color: '#94a3b8' } }
                    }
                }
            });
        })
        .catch(err => console.error("Error loading Module 2 data:", err));
}

/**
 * MODULE 3: Setup live forms, API calls, and history logger
 */
function loadModule3Data() {
    fetchPredictionHistory();
    // Render initial Radar chart
    setTimeout(updateRadarChartLive, 100);
}

function setupPredictionForm() {
    const form = document.getElementById('prediction-form');
    if (!form) return;
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Extract parameters
        const temperature = parseFloat(document.getElementById('input-temp').value);
        const rotational_speed = parseFloat(document.getElementById('input-speed').value);
        const torque = parseFloat(document.getElementById('input-torque').value);
        const tool_wear = parseFloat(document.getElementById('input-wear').value);
        const vibration = parseFloat(document.getElementById('input-vibration').value);
        const pressure = parseFloat(document.getElementById('input-pressure').value);

        const requestBody = {
            temperature,
            rotational_speed,
            torque,
            tool_wear,
            vibration,
            pressure
        };

        // Call API
        fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(`Error: ${data.error}`);
                return;
            }
            
            // Swap placeholder to results layout
            document.getElementById('result-placeholder').classList.add('hidden');
            const resultContent = document.getElementById('result-content');
            resultContent.classList.remove('hidden');

            // Render risk score & failure probability & RUL
            document.getElementById('pred-prob').innerText = `${data.failure_probability}%`;
            document.getElementById('pred-risk').innerText = data.risk_level;
            document.getElementById('pred-recommendation').innerText = data.recommendation;
            
            if (data.rul_hours !== undefined) {
                document.getElementById('pred-rul').innerText = `${data.rul_hours} hrs`;
            }

            // Render health banner colors
            const banner = document.getElementById('health-banner');
            const dot = document.getElementById('health-banner-dot');
            const statusLabel = document.getElementById('health-banner-status');
            const recBox = document.getElementById('rec-box');

            // Clear old health status styles
            banner.className = 'health-status-banner';
            dot.className = 'pulsing-dot';
            recBox.className = 'recommendation-box';

            statusLabel.innerText = data.health_status;

            if (data.health_status === 'NORMAL') {
                banner.classList.add('normal');
                dot.classList.add('ok');
                recBox.classList.add('normal');
            } else if (data.health_status === 'WARNING') {
                banner.classList.add('warning');
                dot.classList.add('alert');
                recBox.classList.add('warning');
            } else {
                banner.classList.add('critical');
                dot.classList.add('crit');
                recBox.classList.add('critical');
            }

            // Store current report data globally for PDF export
            window.latestReport = {
                timestamp: new Date().toLocaleString(),
                inputs: requestBody,
                results: data
            };

            // Reload history lists
            fetchPredictionHistory();
        })
        .catch(err => {
            console.error("Prediction API failed:", err);
            alert("Model prediction failed. Please check backend status.");
        });
    });
}

// Preset Scenario Handler
function loadPreset(presetName) {
    const presets = {
        'optimal': { temp: 65.0, speed: 1500, torque: 4.0, wear: 30, vibration: 3.5, pressure: 95.0 },
        'thermal': { temp: 92.5, speed: 2200, torque: 6.8, wear: 110, vibration: 6.8, pressure: 118.0 },
        'wear': { temp: 74.0, speed: 1800, torque: 5.5, wear: 215, vibration: 8.2, pressure: 108.0 },
        'vibe': { temp: 78.5, speed: 2500, torque: 7.9, wear: 160, vibration: 12.8, pressure: 132.0 },
        'critical': { temp: 105.0, speed: 2850, torque: 9.2, wear: 235, vibration: 14.2, pressure: 152.0 }
    };

    const target = presets[presetName];
    if (!target) return;

    document.getElementById('input-temp').value = target.temp;
    document.getElementById('val-temp').value = target.temp;

    document.getElementById('input-speed').value = target.speed;
    document.getElementById('val-speed').value = target.speed;

    document.getElementById('input-torque').value = target.torque;
    document.getElementById('val-torque').value = target.torque;

    document.getElementById('input-wear').value = target.wear;
    document.getElementById('val-wear').value = target.wear;

    document.getElementById('input-vibration').value = target.vibration;
    document.getElementById('val-vibration').value = target.wear;

    document.getElementById('input-pressure').value = target.pressure;
    document.getElementById('val-pressure').value = target.pressure;

    // Trigger update on live charts
    updateRadarChart();
    
    // Auto submit form for smooth demonstration
    document.getElementById('prediction-form').dispatchEvent(new Event('submit'));
}

// Export Diagnostic Report
function exportDiagnosticReport() {
    if (!window.latestReport) {
        alert("Please run a prediction first before exporting the report.");
        return;
    }

    const report = window.latestReport;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Maintenance Diagnostic Inspection Report</title>
            <style>
                body { font-family: 'Helvetica Neue', Arial, sans-serif; padding: 40px; color: #1e293b; background: #fff; }
                .header { border-bottom: 2px solid #0284c7; padding-bottom: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
                .title { font-size: 24px; font-weight: bold; color: #0f172a; }
                .subtitle { font-size: 14px; color: #64748b; }
                .badge { padding: 6px 12px; border-radius: 4px; font-weight: bold; display: inline-block; font-size: 14px; }
                .badge.NORMAL { background: #dcfce7; color: #15803d; }
                .badge.WARNING { background: #fef3c7; color: #b45309; }
                .badge.CRITICAL { background: #fee2e2; color: #b91c1c; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { border: 1px solid #e2e8f0; padding: 10px; text-align: left; }
                th { background: #f8fafc; font-weight: 600; }
                .rec-box { background: #f0f9ff; border-left: 4px solid #0284c7; padding: 15px; margin-top: 20px; border-radius: 4px; }
                .footer { margin-top: 40px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 15px; }
            </style>
        </head>
        <body>
            <div class="header">
                <div>
                    <div class="title">INDUSTRIAL EQUIPMENT DIAGNOSTIC REPORT</div>
                    <div class="subtitle">Intelligent Predictive Maintenance System</div>
                </div>
                <div class="badge ${report.results.health_status}">${report.results.health_status} RISK</div>
            </div>

            <p><strong>Inspection Timestamp:</strong> ${report.timestamp}</p>
            
            <h3>1. Sensor Telemetry Readings</h3>
            <table>
                <tr><th>Parameter</th><th>Measured Value</th><th>Standard Baseline</th></tr>
                <tr><td>Temperature</td><td>${report.inputs.temperature} °C</td><td>25.0 - 75.0 °C</td></tr>
                <tr><td>Rotational Speed</td><td>${report.inputs.rotational_speed} RPM</td><td>1000 - 2000 RPM</td></tr>
                <tr><td>Torque</td><td>${report.inputs.torque} Nm</td><td>1.0 - 6.0 Nm</td></tr>
                <tr><td>Tool Wear</td><td>${report.inputs.tool_wear} min</td><td>0 - 150 min</td></tr>
                <tr><td>Vibration</td><td>${report.inputs.vibration} mm/s</td><td>0.5 - 6.0 mm/s</td></tr>
                <tr><td>System Pressure</td><td>${report.inputs.pressure} bar</td><td>80.0 - 120.0 bar</td></tr>
            </table>

            <h3>2. AI Failure Prognostics & RUL</h3>
            <table>
                <tr><th>Failure Hazard Probability</th><td><strong>${report.results.failure_probability}%</strong></td></tr>
                <tr><th>Risk Classification</th><td><strong>${report.results.risk_level}</strong></td></tr>
                <tr><th>Estimated Remaining Useful Life (RUL)</th><td><strong>${report.results.rul_hours} Operating Hours</strong></td></tr>
            </table>

            <div class="rec-box">
                <h4>Maintenance Action Plan</h4>
                <p>${report.results.recommendation}</p>
            </div>

            <div class="footer">
                Report automatically generated by Intelligent Predictive Maintenance System ML Engine • Confidential Industrial Asset Audit
            </div>
            <script>
                window.onload = function() { window.print(); }
            </script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

// Process Batch CSV Telemetry File
function processBatchCSV() {
    const fileInput = document.getElementById('batch-csv-input');
    if (!fileInput.files || fileInput.files.length === 0) {
        alert("Please select a CSV file first.");
        return;
    }

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    fetch('/api/batch-predict', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            alert(`Batch Error: ${data.error}`);
            return;
        }

        document.getElementById('batch-results-container').classList.remove('hidden');
        document.getElementById('batch-total-rows').innerText = data.total_rows;
        document.getElementById('batch-failures').innerText = data.predicted_failures;
        document.getElementById('batch-healthy').innerText = data.predicted_healthy;
        document.getElementById('batch-rate').innerText = `${data.failure_rate_pct}%`;
    })
    .catch(err => {
        console.error("Batch CSV API failed:", err);
        alert("Failed to process batch CSV. Ensure columns match required sensor names.");
    });
}


function fetchPredictionHistory() {
    fetch('/api/prediction-history')
        .then(res => res.json())
        .then(history => {
            const tableBody = document.getElementById('history-table-body');
            if (!tableBody) return;
            
            if (history.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No predictions logged yet.</td></tr>';
                return;
            }

            tableBody.innerHTML = '';
            // Display newest first
            history.reverse().forEach(row => {
                const tr = document.createElement('tr');
                const badgeClass = row.result.health_status.toLowerCase();
                tr.innerHTML = `
                    <td>${row.timestamp.split(' ')[1] || row.timestamp}</td>
                    <td>${row.inputs.temperature.toFixed(0)}°C / ${row.inputs.rotational_speed.toFixed(0)} RPM / ${row.inputs.vibration.toFixed(1)}v</td>
                    <td><span class="history-badge ${badgeClass}">${row.result.health_status}</span></td>
                    <td>${row.result.risk_level}</td>
                    <td><strong>${row.result.failure_probability}%</strong></td>
                `;
                tableBody.appendChild(tr);
            });
        })
        .catch(err => console.error("Error loading prediction history:", err));
}

/**
 * Render/Update Module 3 Radar Chart to represent live sliding variables relative to typical boundaries
 */
function updateRadarChartLive() {
    const ctxRadar = document.getElementById('m3-radar-chart').getContext('2d');
    
    // Gather values
    const temp = parseFloat(document.getElementById('input-temp').value);
    const speed = parseFloat(document.getElementById('input-speed').value);
    const torque = parseFloat(document.getElementById('input-torque').value);
    const wear = parseFloat(document.getElementById('input-wear').value);
    const vibe = parseFloat(document.getElementById('input-vibration').value);
    const press = parseFloat(document.getElementById('input-pressure').value);

    // Normalize inputs relative to standard bounds for visualization (0 to 100 scale)
    const normTemp = ((temp - 25) / (120 - 25)) * 100;
    const normSpeed = ((speed - 500) / (3000 - 500)) * 100;
    const normTorque = ((torque - 0.5) / (10 - 0.5)) * 100;
    const normWear = (wear / 240) * 100;
    const normVibe = ((vibe - 0.1) / (15 - 0.1)) * 100;
    const normPress = ((press - 30) / (160 - 30)) * 100;

    const currentData = [normTemp, normSpeed, normTorque, normWear, normVibe, normPress];
    const thresholdData = [70, 70, 70, 75, 65, 75]; // Warning boundaries

    if (m3RadarChart) {
        m3RadarChart.data.datasets[0].data = currentData;
        m3RadarChart.update();
    } else {
        m3RadarChart = new Chart(ctxRadar, {
            type: 'radar',
            data: {
                labels: ['Temperature', 'Rotational Speed', 'Torque', 'Tool Wear', 'Vibration', 'Pressure'],
                datasets: [
                    {
                        label: 'Current Live Operations',
                        data: currentData,
                        fill: true,
                        backgroundColor: 'rgba(0, 242, 254, 0.25)',
                        borderColor: '#00f2fe',
                        pointBackgroundColor: '#00f2fe',
                        pointBorderColor: '#fff'
                    },
                    {
                        label: 'Warning Threshold Boundaries',
                        data: thresholdData,
                        fill: false,
                        borderColor: 'rgba(239, 68, 68, 0.4)',
                        borderDash: [5, 5],
                        pointBackgroundColor: 'transparent',
                        pointBorderColor: 'transparent'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#f1f5f9' } }
                },
                scales: {
                    r: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        angleLines: { color: 'rgba(255, 255, 255, 0.05)' },
                        pointLabels: { color: '#94a3b8', font: { size: 10 } },
                        ticks: { display: false },
                        suggestedMin: 0,
                        suggestedMax: 100
                    }
                }
            }
        });
    }
}
