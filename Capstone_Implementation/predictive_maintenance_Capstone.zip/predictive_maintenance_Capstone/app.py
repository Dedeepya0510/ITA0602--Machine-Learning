from flask import Flask, request, jsonify, render_template
import os
import json
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__, static_folder='static', template_folder='templates')

script_dir = os.path.dirname(os.path.abspath(__file__))
stats_path = os.path.join(script_dir, 'model_stats.json')
model_path = os.path.join(script_dir, 'best_model.joblib')
scaler_path = os.path.join(script_dir, 'scaler.joblib')
history_path = os.path.join(script_dir, 'prediction_history.json')

# Check if model files exist; if not, train them
if not os.path.exists(model_path) or not os.path.exists(scaler_path) or not os.path.exists(stats_path):
    print("Pre-trained models not found. Running training script...")
    import train
    train.run_preprocessing_and_training()

# Helper function to read model_stats.json
def load_model_stats():
    if os.path.exists(stats_path):
        with open(stats_path, 'r') as f:
            return json.load(f)
    return {}

# Helper function to read prediction history
def load_prediction_history():
    if os.path.exists(history_path):
        try:
            with open(history_path, 'r') as f:
                return json.load(f)
        except Exception:
            return []
    return []

# Helper function to save prediction history
def save_prediction_history(history):
    with open(history_path, 'w') as f:
        json.dump(history, f, indent=4)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/sensor-data', methods=['GET'])
def get_sensor_data():
    """
    Returns data acquisition and preprocessing metrics (Module 1).
    """
    stats = load_model_stats()
    if 'eda_stats' in stats:
        return jsonify(stats['eda_stats'])
    return jsonify({"error": "Sensor statistics data not found"}), 404

@app.route('/api/model-info', methods=['GET'])
def get_model_info():
    """
    Returns model training comparison, feature importances, and best model stats (Module 2).
    """
    stats = load_model_stats()
    if stats:
        return jsonify({
            'best_model_name': stats.get('best_model_name', 'Decision Tree'),
            'model_comparison': stats.get('model_comparison', {}),
            'confusion_matrix': stats.get('confusion_matrix', {}),
            'feature_importances': stats.get('feature_importances', {}),
            'saved_model_status': stats.get('saved_model_status', 'Saved & Loaded')
        })
    return jsonify({"error": "Model stats metadata not found"}), 404

@app.route('/api/predict', methods=['POST'])
def predict():
    """
    Predicts machine failure based on 6 input sensors (Module 3).
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No input data provided"}), 400
        
        # Read parameters
        temp = float(data.get('temperature', 65.0))
        speed = float(data.get('rotational_speed', 1500.0))
        torque = float(data.get('torque', 4.0))
        wear = float(data.get('tool_wear', 50.0))
        vibration = float(data.get('vibration', 5.0))
        pressure = float(data.get('pressure', 100.0))
        
        # Load scaler and model
        scaler = joblib.load(scaler_path)
        model = joblib.load(model_path)
        
        # Feature names in training order:
        # Temperature, Rotational_Speed, Torque, Tool_Wear, Vibration, Pressure
        input_features = pd.DataFrame([{
            'Temperature': temp,
            'Rotational_Speed': speed,
            'Torque': torque,
            'Tool_Wear': wear,
            'Vibration': vibration,
            'Pressure': pressure
        }])
        
        # Preprocess using the trained scaler
        input_scaled = scaler.transform(input_features)
        
        # Run inference
        prediction = int(model.predict(input_scaled)[0])
        
        # Get probability
        if hasattr(model, 'predict_proba'):
            prob = float(model.predict_proba(input_scaled)[0][1])
        else:
            prob = 1.0 if prediction == 1 else 0.0
            
        prob_pct = round(prob * 100, 1)
        
        # Determine health status, risk level, and recommendation
        if prob_pct < 30.0:
            health_status = 'NORMAL'
            risk_level = 'LOW'
            recommendation = (
                "✓ Machine health is optimal. No action required. "
                "Schedule standard routine inspection in 48 operating hours."
            )
        elif prob_pct < 70.0:
            health_status = 'WARNING'
            risk_level = 'MEDIUM'
            recommendation = (
                "⚠️ Equipment showing moderate mechanical/thermal stress. "
                "Schedule diagnostic maintenance within next 12 operating hours. Monitor vibrations."
            )
        else:
            health_status = 'CRITICAL'
            risk_level = 'HIGH'
            recommendation = (
                "❌ CRITICAL FAILURE RISK DETECTED! Shut down equipment immediately. "
                "Inspect spindle motor alignment, tool wear, and heat dissipation ports."
            )
            
        # Estimate Remaining Useful Life (RUL in hours)
        base_lifespan = 120.0 # Maximum standard operating cycle hours
        wear_factor = max(0.1, 1.0 - (wear / 300.0))
        health_factor = max(0.01, 1.0 - prob)
        rul_hours = max(0.5, round(base_lifespan * health_factor * wear_factor, 1))
        if prediction == 1 and prob_pct > 80:
            rul_hours = round(min(rul_hours, 2.5), 1)

        result = {
            'prediction': prediction,
            'failure_probability': prob_pct,
            'risk_level': risk_level,
            'health_status': health_status,
            'recommendation': recommendation,
            'rul_hours': rul_hours
        }
        
        # Log to prediction history (Feedback Loop)
        history = load_prediction_history()
        history.append({
            'timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
            'inputs': {
                'temperature': temp,
                'rotational_speed': speed,
                'torque': torque,
                'tool_wear': wear,
                'vibration': vibration,
                'pressure': pressure
            },
            'result': result
        })
        save_prediction_history(history)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": f"Failed to calculate prediction: {str(e)}"}), 500

@app.route('/api/prediction-history', methods=['GET'])
def get_prediction_history():
    """
    Returns prediction history database (Feedback Loop log).
    """
    history = load_prediction_history()
    # Return last 20 entries
    return jsonify(history[-20:])

@app.route('/api/batch-predict', methods=['POST'])
def batch_predict():
    """
    Processes batch telemetry CSV input files (Module 1/3 Advanced Feature).
    """
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No CSV file uploaded"}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No file selected"}), 400
            
        df_batch = pd.read_csv(file)
        required_cols = ['Temperature', 'Rotational_Speed', 'Torque', 'Tool_Wear', 'Vibration', 'Pressure']
        
        # Check column presence
        missing_cols = [col for col in required_cols if col not in df_batch.columns]
        if missing_cols:
            return jsonify({"error": f"Missing required CSV columns: {', '.join(missing_cols)}"}), 400
            
        scaler = joblib.load(scaler_path)
        model = joblib.load(model_path)
        
        # Fill missing values if any
        for col in required_cols:
            df_batch[col].fillna(df_batch[col].median(), inplace=True)
            
        scaled_batch = scaler.transform(df_batch[required_cols])
        preds = model.predict(scaled_batch)
        
        if hasattr(model, 'predict_proba'):
            probs = model.predict_proba(scaled_batch)[:, 1]
        else:
            probs = [1.0 if p == 1 else 0.0 for p in preds]
            
        df_batch['Predicted_Failure'] = preds
        df_batch['Failure_Probability_%'] = (probs * 100).round(1)
        
        total_samples = len(df_batch)
        failures_found = int((preds == 1).sum())
        healthy_found = total_samples - failures_found
        
        summary = {
            'total_rows': total_samples,
            'predicted_failures': failures_found,
            'predicted_healthy': healthy_found,
            'failure_rate_pct': round((failures_found / total_samples) * 100, 1),
            'sample_predictions': df_batch.head(10).to_dict(orient='records')
        }
        
        return jsonify(summary)
    except Exception as e:
        return jsonify({"error": f"Batch processing failed: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False, port=5000)

