import pandas as pd
import numpy as np
import os
import json
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

np.random.seed(42)

def generate_and_save_data(n_samples=3000):
    """
    Generates synthetic machine telemetry data.
    Intentionally injects missing values and duplicates to demonstrate pre-processing.
    """
    print("Generating synthetic industrial telemetry dataset...")
    
    # Generate features
    temperature = np.random.normal(loc=65.0, scale=12.0, size=n_samples) # in Celsius (40 - 100)
    rotational_speed = np.random.normal(loc=1700, scale=250, size=n_samples) # RPM (1000 - 2500)
    torque = np.random.normal(loc=4.2, scale=1.1, size=n_samples) # Nm (1 - 8)
    tool_wear = np.random.uniform(low=0, high=240, size=n_samples) # minutes (0 - 240)
    vibration = np.random.normal(loc=6.0, scale=2.0, size=n_samples) # mm/s (1 - 12)
    pressure = np.random.normal(loc=95.0, scale=15.0, size=n_samples) # bar (50 - 140)
    
    # Clip values to physically realistic limits
    temperature = np.clip(temperature, 25.0, 120.0)
    rotational_speed = np.clip(rotational_speed, 500, 3000)
    torque = np.clip(torque, 0.5, 10.0)
    vibration = np.clip(vibration, 0.1, 15.0)
    pressure = np.clip(pressure, 30.0, 160.0)
    
    # Physics-grounded failure logic
    # Failure probability increases with:
    # 1. Thermal strain (high process temperature)
    temp_risk = 1 / (1 + np.exp(-0.25 * (temperature - 78.0)))
    
    # 2. Overload (High speed combined with high torque)
    power_risk = 1 / (1 + np.exp(-0.01 * (rotational_speed * torque - 7500.0)))
    
    # 3. Structural strain (High vibration)
    vibe_risk = 1 / (1 + np.exp(-0.8 * (vibration - 7.5)))
    
    # 4. Tool exhaustion (Severe tool wear)
    wear_risk = 1 / (1 + np.exp(-0.06 * (tool_wear - 140.0)))
    
    # 5. Pressure surge
    pressure_risk = 1 / (1 + np.exp(-0.15 * (pressure - 115.0)))
    
    # Combine risk probabilities
    combined_risk = 0.3 * temp_risk + 0.2 * power_risk + 0.2 * vibe_risk + 0.15 * wear_risk + 0.15 * pressure_risk
    
    # Direct high-stress failures
    direct_fail = (temperature > 85.0) | (vibration > 9.0) | (tool_wear > 175.0) | (pressure > 120.0) | (torque > 7.5)
    combined_risk = np.where(direct_fail, np.maximum(combined_risk, 0.85), combined_risk)
    
    # Add a base failure rate + noise
    combined_risk = np.clip(combined_risk + np.random.normal(loc=0, scale=0.03, size=n_samples), 0.0, 1.0)
    
    # Binary label: 1 if failure, 0 if healthy
    failure = (combined_risk > 0.45).astype(int)
    
    df_raw = pd.DataFrame({
        'Temperature': temperature,
        'Rotational_Speed': rotational_speed,
        'Torque': torque,
        'Tool_Wear': tool_wear,
        'Vibration': vibration,
        'Pressure': pressure,
        'Failure': failure
    })
    
    # INJECT ISSUES FOR MODULE 1 DEMONSTRATION
    # 1. Inject duplicate rows (e.g. 15 duplicates)
    dup_indices = np.random.choice(df_raw.index, size=15, replace=False)
    duplicates = df_raw.iloc[dup_indices].copy()
    df_raw = pd.concat([df_raw, duplicates], ignore_index=True)
    
    # 2. Inject missing values (NaNs) (e.g. 20 in Temperature, 12 in Vibration, 8 in Torque)
    nan_temp_idx = np.random.choice(df_raw.index, size=20, replace=False)
    nan_vibe_idx = np.random.choice(df_raw.index, size=12, replace=False)
    nan_trq_idx = np.random.choice(df_raw.index, size=8, replace=False)
    
    df_raw.loc[nan_temp_idx, 'Temperature'] = np.nan
    df_raw.loc[nan_vibe_idx, 'Vibration'] = np.nan
    df_raw.loc[nan_trq_idx, 'Torque'] = np.nan
    
    return df_raw

def run_preprocessing_and_training():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 1. Get raw dataset
    df_raw = generate_and_save_data()
    
    # Calculate statistics for Module 1 dashboard
    total_records_raw = len(df_raw)
    missing_temp = df_raw['Temperature'].isnull().sum()
    missing_vibe = df_raw['Vibration'].isnull().sum()
    missing_torque = df_raw['Torque'].isnull().sum()
    total_missing = int(missing_temp + missing_vibe + missing_torque)
    
    total_duplicates = int(df_raw.duplicated().sum())
    
    # Outlier detection (IQR method on non-null values)
    outliers_count = 0
    features = ['Temperature', 'Rotational_Speed', 'Torque', 'Tool_Wear', 'Vibration', 'Pressure']
    for feat in features:
        feat_data = df_raw[feat].dropna()
        q1 = feat_data.quantile(0.25)
        q3 = feat_data.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        outliers_count += int(((feat_data < lower_bound) | (feat_data > upper_bound)).sum())

    # 2. Data Preprocessing Flow
    print("Preprocessing data: Handling missing values, duplicates, and outliers...")
    
    # Missing Value Handling (median imputation)
    df_clean = df_raw.copy()
    for feat in features:
        median_val = df_clean[feat].median()
        df_clean[feat].fillna(median_val, inplace=True)
        
    # Duplicate Removal
    df_clean.drop_duplicates(inplace=True)
    total_records_clean = len(df_clean)
    
    # Save the processed dataset to show in EDA/Module 1
    # Generate statistics for EDA charts
    eda_stats = {
        'total_records_raw': total_records_raw,
        'total_records_clean': total_records_clean,
        'missing_values': {
            'Temperature': int(missing_temp),
            'Vibration': int(missing_vibe),
            'Torque': int(missing_torque),
            'Total': total_missing
        },
        'duplicates': total_duplicates,
        'outliers': outliers_count,
        'features': features,
        'selected_features': features, # Using all 6 as vital features
        # Failure breakdown
        'failures_count': int(df_clean['Failure'].sum()),
        'healthy_count': int((df_clean['Failure'] == 0).sum()),
        # Temperature distribution by Failure type
        'temp_fail_mean': float(df_clean[df_clean['Failure'] == 1]['Temperature'].mean()),
        'temp_healthy_mean': float(df_clean[df_clean['Failure'] == 0]['Temperature'].mean()),
        # Vibration distribution by Failure type
        'vibe_fail_mean': float(df_clean[df_clean['Failure'] == 1]['Vibration'].mean()),
        'vibe_healthy_mean': float(df_clean[df_clean['Failure'] == 0]['Vibration'].mean()),
        # Speed vs Torque scatter subset for EDA (limit to 100 rows to keep JSON light)
        'eda_scatter_data': df_clean.sample(150, random_state=42)[['Rotational_Speed', 'Torque', 'Failure']].to_dict(orient='records')
    }

    # 3. Model Training
    print("Scaling features and splitting dataset...")
    X = df_clean[features]
    y = df_clean['Failure']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Feature Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Save scaler
    joblib.dump(scaler, os.path.join(script_dir, 'scaler.joblib'))
    print("Scaler saved successfully.")
    
    # Define models
    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Decision Tree': DecisionTreeClassifier(max_depth=5, random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42),
        'Support Vector Machine': SVC(probability=True, random_state=42),
        'XGBoost': XGBClassifier(n_estimators=100, max_depth=5, random_state=42, eval_metric='logloss')
    }
    
    model_metrics = {}
    trained_models = {}
    
    print("Training 5 Machine Learning models...")
    for name, model in models.items():
        # Fit model
        if name == 'XGBoost':
            model.fit(X_train_scaled, y_train)
        else:
            model.fit(X_train_scaled, y_train)
            
        # Predict
        y_pred = model.predict(X_test_scaled)
        
        # Calculate metrics
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, zero_division=0)
        rec = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        
        # ROC AUC
        if hasattr(model, "predict_proba"):
            y_prob = model.predict_proba(X_test_scaled)[:, 1]
            auc = roc_auc_score(y_test, y_prob)
        else:
            y_prob = model.decision_function(X_test_scaled)
            auc = roc_auc_score(y_test, y_prob)
            
        model_metrics[name] = {
            'Accuracy': float(acc),
            'Precision': float(prec),
            'Recall': float(rec),
            'F1-Score': float(f1),
            'ROC-AUC': float(auc)
        }
        trained_models[name] = model
        print(f"-> {name} trained. F1-Score: {f1:.4f}")
        
    # 4. Select the best model automatically based on F1-Score
    best_model_name = max(model_metrics, key=lambda k: model_metrics[k]['F1-Score'])
    best_model = trained_models[best_model_name]
    print(f"\nBest Performing Model selected: {best_model_name}")
    
    # Save the best model
    joblib.dump(best_model, os.path.join(script_dir, 'best_model.joblib'))
    print("Best model saved successfully.")
    
    # 5. Generate confusion matrix for the best model
    y_pred_best = best_model.predict(X_test_scaled)
    cm = confusion_matrix(y_test, y_pred_best)
    # cm format: [[TN, FP], [FN, TP]]
    cm_dict = {
        'TN': int(cm[0][0]),
        'FP': int(cm[0][1]),
        'FN': int(cm[1][0]),
        'TP': int(cm[1][1])
    }
    
    # 6. Feature Importance / SHAP Proxy
    # We will compute feature importances using the Random Forest classifier,
    # as it is stable, explainable, and available for all features.
    rf_model = trained_models['Random Forest']
    importances = rf_model.feature_importances_
    
    # Normalize importance to percentages
    importances_pct = (importances / importances.sum()) * 100
    feature_importances = {feat: float(score) for feat, score in zip(features, importances_pct)}
    
    # Sort feature importances descending
    feature_importances = dict(sorted(feature_importances.items(), key=lambda item: item[1], reverse=True))
    
    # Compile training metadata
    train_metadata = {
        'best_model_name': best_model_name,
        'model_comparison': model_metrics,
        'confusion_matrix': cm_dict,
        'feature_importances': feature_importances,
        'eda_stats': eda_stats,
        'saved_model_status': 'Saved & Loaded'
    }
    
    # Save to JSON
    with open(os.path.join(script_dir, 'model_stats.json'), 'w') as f:
        json.dump(train_metadata, f, indent=4)
    print("Training stats metadata JSON saved.")

if __name__ == '__main__':
    run_preprocessing_and_training()
